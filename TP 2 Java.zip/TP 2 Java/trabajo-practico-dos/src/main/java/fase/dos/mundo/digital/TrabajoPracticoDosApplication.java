package fase.dos.mundo.digital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoPracticoDosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoPracticoDosApplication.class, args);
	}

}
