package fase.dos.mundo.digital.interfaz;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import fase.dos.mundo.digital.fichaTecnica.Vehiculo;

public class Concesionaria implements IVehiculo {

    List<Vehiculo> vehiculos = new ArrayList<>();

    /**
     * La agregacion de uno o varios vehículo a la lista de la concesionaria
     * 
     * @param vehiculo vehículo que se desea agregar a la lista
     */
    public void agregarVehiculo(Vehiculo... vehiculosIngresados) {
        for (int i = 0; i < vehiculosIngresados.length; i++) {
            vehiculos.add(vehiculosIngresados[i]);
        }
    }

    /**
     * La eliminacion de uno o varios vehículo a la lista de la concesionaria
     * 
     * @param vehiculo vehículo que se desea eliminar a la lista
     */
    public void eliminarVehiculo(Vehiculo... vehiculosEliminado) {
        for (int i = 0; i < vehiculosEliminado.length; i++) {
            vehiculos.remove(vehiculosEliminado[i]);
        }
    }

    /**
     * Muestra el recorrido de los objetos de la lista de vehiculos registrados.
     */
    @Override
    public void mostrarFicha() {
        vehiculos.forEach(System.out::println);
    }

    /**
     * Busca el vehículo con el precio más alto y lo muestra en consola por (marca y modelo)
     */
    @Override
    public void precioMayor() {
        vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .ifPresent(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Busca el vehículo con el precio más bajo y lo muestra en consola por (marca y modelo)
     */
    @Override
    public void precioMenor() {
        vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .ifPresent(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Busca y muestra los vehículos cuyo modelo contiene el texto o letra indicado
     * (no es busqueda global)
     * 
     * @param letra texto o letra que se desea buscar en el modelo de vehiculo
     */
    @Override
    public void buscadorVehiculo(String letra) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        vehiculos
                .stream()
                .filter(v -> v.getModelo().toUpperCase().contains(letra.toUpperCase()))
                .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra '" + letra + "': "
                        + v.getMarca() + " "
                        + v.getModelo() + " $"
                        + df.format(v.getPrecio())));
    }

    /**
     * Ordenamiento de los vehículos por el precio de mayor a menor, mostrando su
     * marca y modelo por consola
     */
    @Override
    public void ordenPrecioMayorAmenor() {
        System.out.println("Vehículos ordenados por precio de mayor a menor: ");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Ordenamiento de los vehículos por el precio de menor a mayor, mostrando su
     * marca y modelo por consola
     */
    @Override
    public void ordenPrecioMenorAmayor() {
        System.out.println("Vehículos ordenados por precio de menor a mayor: ");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio))
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Ordenamiento de los vehículos por su orden natural, definido
     * mediante el método compareTo() de la clase Vehiculo,
     * y los muestra por consola
     */
    @Override
    public void ordenamientoNatural() {
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio): ");
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }


    public void buscador(String buscar) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        System.out.println("Vehículo con la marca o modelo '" + buscar + "':");
        vehiculos
                .stream()
                .filter(v -> v.getMarca().toLowerCase().contains(buscar)
                        || v.getModelo().toLowerCase().contains(buscar))
                .forEach(v -> System.out.println("Marca: " + v.getMarca() + " | Modelo: " + v.getModelo()
                        + " | Precio: $" + df.format(v.getPrecio())));
    }

}
