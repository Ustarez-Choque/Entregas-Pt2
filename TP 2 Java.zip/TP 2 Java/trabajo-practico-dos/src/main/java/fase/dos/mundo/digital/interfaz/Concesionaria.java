package fase.dos.mundo.digital.interfaz;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import fase.dos.mundo.digital.fichaTecnica.Vehiculo;

public class Concesionaria implements IVehiculo {

    List<Vehiculo> vehiculos = new ArrayList<>();

    /**
     * Agrega uno o varios vehículos a la lista de vehículos de la concesionaria.
     * Utiliza parámetros variables (varargs), representados mediante tres puntos (...),
     * lo que permite recibir una cantidad variable de objetos Vehiculo en una misma
     * llamada al método, sin necesidad de pasar un arreglo explícitamente.
     *
     * @param vehiculosIngresados uno o varios vehículos que se desean agregar a la lista de la concesionaria
     */
    public void agregarVehiculo(Vehiculo... vehiculosIngresados) {
        for (int i = 0; i < vehiculosIngresados.length; i++) {
            vehiculos.add(vehiculosIngresados[i]);
        }
    }

    /**
     * Elimina uno o varios vehículos de la lista de vehículos de la concesionaria. 
     * Utiliza parámetros variables (varargs), representados mediante tres puntos (...),
     * lo que permite recibir una cantidad variable de objetos Vehiculo en una misma
     * llamada al método, sin necesidad de pasar un arreglo explícitamente.
     *
     * @param vehiculosEliminado uno o varios vehículos que se desean eliminar de la lista de la concesionaria
     */
    public void eliminarVehiculo(Vehiculo... vehiculosEliminado) {
        for (int i = 0; i < vehiculosEliminado.length; i++) {
            vehiculos.remove(vehiculosEliminado[i]);
        }
    }

    @Override
    public void mostrarFicha() {
        vehiculos.forEach(System.out::println);
    }

    @Override
    public void obtenerPrecioMayor() {
        vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .ifPresent(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void obtenerPrecioMenor() {
        vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .ifPresent(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void buscadorVehiculo(String letra) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        vehiculos
                .stream()
                .filter(v -> v.getModelo().toUpperCase().contains(letra.toUpperCase()))
                .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra '" + letra + "': "
                        + v.getMarca() + " "
                        + v.getModelo() + " $"
                        + df.format(v.getPrecio())));
    }

    @Override
    public void ordenPrecioMayorAmenor() {
        System.out.println("Vehículos ordenados por precio de mayor a menor: ");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void ordenPrecioMenorAmayor() {
        System.out.println("Vehículos ordenados por precio de menor a mayor: ");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio))
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void ordenamientoNatural() {
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio): ");
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }

    /**
     * Busca y muestra los vehículos cuya marca o modelo contenga el texto
     * ingresado, sin importar si coincide con una letra o una palabra completa.
     * La búsqueda no distingue entre mayúsculas y minúsculas.
     * Muestra por consola la marca, el modelo y el precio de cada vehículo
     * encontrado, formateando el precio con dos decimales.
     *
     * @param buscar texto o letra que se desea buscar dentro de la marca o modelo
     */
    public void buscador(String buscar) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        System.out.println("Vehículo con la marca o modelo '" + buscar + "':");
        vehiculos
                .stream()
                .filter(v -> v.getMarca().toLowerCase().contains(buscar.toLowerCase())
                        || v.getModelo().toLowerCase().contains(buscar.toLowerCase()))
                .forEach(v -> System.out.println("Marca: " + v.getMarca() + " | Modelo: " + v.getModelo()
                        + " | Precio: $" + df.format(v.getPrecio())));
    }

}
