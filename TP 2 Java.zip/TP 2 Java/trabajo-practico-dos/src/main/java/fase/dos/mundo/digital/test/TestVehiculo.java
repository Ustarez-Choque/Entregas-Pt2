package fase.dos.mundo.digital.test;

import fase.dos.mundo.digital.fichaTecnica.Auto;
import fase.dos.mundo.digital.fichaTecnica.Moto;
import fase.dos.mundo.digital.interfaz.Concesionaria;

public class TestVehiculo {
        public static void main(String[] args) {

                Concesionaria lista1 = new Concesionaria();

                Auto auto1 = new Auto("Peugeot", "206", 4, 200000);
                Moto moto1 = new Moto("Honda", "Titan", 125, 60000);
                Auto auto2 = new Auto("Peugeot", "208", 5, 250000);
                Moto moto2 = new Moto("Yamaha", "YBR", 160, 80500.50);

                System.out.println();

                lista1.agregarVehiculo(auto1, moto1, auto2, moto2);
                lista1.mostrarFicha();

                System.out.println("\n=============================\n");

                lista1.precioMayor();
                lista1.precioMenor();
                lista1.buscadorVehiculo("Y");

                System.out.println("\n=============================\n");

                lista1.ordenPrecioMayorAmenor();

                System.out.println("\n=============================\n");
                
                lista1.ordenamientoNatural();

        }
}
