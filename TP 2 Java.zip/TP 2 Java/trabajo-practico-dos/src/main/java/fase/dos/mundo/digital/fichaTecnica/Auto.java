package fase.dos.mundo.digital.fichaTecnica;

import java.text.DecimalFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Auto extends Vehiculo {

    private int puerta;

    public Auto(String marca, String modelo, int puesta, double precio) {
        super(marca, modelo, precio);
        this.puerta = puesta;
    }

    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        return "Marca: " + getMarca()
                + " // Modelo: " + getModelo()
                + " // Puertas: " + puerta
                + " // Precio: $" + df.format(getPrecio());
    }

}
