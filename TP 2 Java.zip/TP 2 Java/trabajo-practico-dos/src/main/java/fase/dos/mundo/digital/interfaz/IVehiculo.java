package fase.dos.mundo.digital.interfaz;

public interface IVehiculo {

    /**
     * Muestra el recorrido de los objetos de la lista de vehiculos registrados.
     */
    void mostrarFicha();

    /**
     * Busca el vehículo con el precio más alto y lo muestra en consola por (marca y
     * modelo)
     */
    void obtenerPrecioMayor();

    /**
     * Busca el vehículo con el precio más bajo y lo muestra en consola por (marca y
     * modelo)
     */
    void obtenerPrecioMenor();

    /**
     * Busca y muestra los vehículos cuyo modelo contiene el texto o letra indicado
     * (no es busqueda global)
     * 
     * @param letra texto o letra que se desea buscar en el modelo de vehiculo
     */
    void buscadorVehiculo(String letra);

    /**
     * Ordenamiento de los vehículos por el precio de mayor a menor, mostrando su
     * marca y modelo por consola
     */
    void ordenPrecioMayorAmenor();

    /**
     * Ordenamiento de los vehículos por el precio de menor a mayor, mostrando su
     * marca y modelo por consola
     */
    void ordenPrecioMenorAmayor();

    /**
     * Ordenamiento de los vehículos por su orden natural, definido
     * mediante el método compareTo() de la clase Vehiculo,
     * y los muestra por consola
     */
    void ordenamientoNatural();

}
