package fase.dos.mundo.digital.interfaz;

public interface IVehiculo {

    void mostrarFicha();

    void precioMayor();

    void precioMenor();

    void buscadorVehiculo(String letra);

    void ordenPrecioMayorAmenor();

    void ordenPrecioMenorAmayor();

    void ordenamientoNatural();

}
