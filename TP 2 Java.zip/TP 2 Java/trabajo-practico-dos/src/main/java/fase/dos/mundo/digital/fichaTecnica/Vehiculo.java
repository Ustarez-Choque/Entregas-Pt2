package fase.dos.mundo.digital.fichaTecnica;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data 
@AllArgsConstructor

public abstract class Vehiculo implements Comparable<Vehiculo> {

    private String marca, modelo;
    private double precio;

    @Override
    public int compareTo(Vehiculo otroVehiculo) {
        // Construye una cadena de texto con la marca, modelo y precio del vehículo actual.
        String esteModelo = this.marca + "," + this.modelo + "," + this.precio; 
        // Construye una cadena de texto con la marca, modelo y precio del vehículo que se recibe como parámetro.
        String otroModelo = otroVehiculo.marca + "," + otroVehiculo.modelo + "," + otroVehiculo.precio;
        // Compara ambas cadenas y devuelve un número entero que indica cuál vehículo va primero según el orden alfabético.
        return esteModelo.compareTo(otroModelo);
    }

}
