package fase.dos.mundo.digital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoPracticoDosApplicationTests {

	@Test
	void contextLoads() {
	}

}
